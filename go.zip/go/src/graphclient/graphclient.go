package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"net/url"
	"time"
  "sync"
  "log"
  "bytes"

	"github.com/mhoc/msgoraph/scopes"
)

// Client is an interface which all client types abide by. It guarantees operations around
// credentials; primarily getting, initializing, and refreshing.
type Client interface {
	Credentials() *RequestCredentials

	// InitializeCredentials should make the initial requests necessary to establish the first set of
	// authentication credentials within the Client.
	InitializeCredentials() error

	// RefreshCredentials should initiate an internal refresh of the request credentials inside this
	// client. This refresh should, whenever possible, check the
	// RequestCredentials.AccessTokenExpiresAt field to determine whether it should actually refresh
	// the credentials or if the credentials are still valid.
	RefreshCredentials() error
}

// RequestCredentials stores all the information necessary to authenticate a request with the
// Microsoft GraphAPI
type RequestCredentials struct {
	AccessToken          string
	AccessTokenExpiresAt time.Time
	AccessTokenUpdating  sync.Mutex
}

// Headless is used to authenticate requests in the context of a backend app. This is the most
// common way for applications to authenticate with the api.
type Headless struct {
	ApplicationID      string
	ApplicationSecret  string
	Error              error
	RefreshToken       string
	RequestCredentials *RequestCredentials
	Scopes             scopes.Scopes
}

// NewHeadless creates a new headless connection.
func NewHeadless(applicationID string, applicationSecret string, scopes scopes.Scopes) *Headless {
	return &Headless{
		ApplicationID:      applicationID,
		ApplicationSecret:  applicationSecret,
		RequestCredentials: &RequestCredentials{},
		Scopes:             scopes,
	}
}

// Credentials returns back the set of credentials used for every request.
func (h Headless) Credentials() *RequestCredentials {
	return h.RequestCredentials
}

// InitializeCredentials will make an initial oauth2 token request for a new token.
func (h Headless) InitializeCredentials() error {
	h.RequestCredentials.AccessTokenUpdating.Lock()
	defer h.RequestCredentials.AccessTokenUpdating.Unlock()
	if h.RequestCredentials.AccessToken != "" && h.RequestCredentials.AccessTokenExpiresAt.After(time.Now()) {
		return nil
	}
	tokenURI, err := url.Parse("https://login.microsoftonline.com/HomeDepot.onmicrosoft.com/oauth2/token")
	if err != nil {
		return err
	}

	resp, err := http.PostForm(tokenURI.String(), url.Values{
		"client_id":     {"76ffe6ac-5d9d-43b5-83d2-f313e3b7372b"},
		"client_secret": {"Sb?Lhx7+9@64+A=LgV*H/]6.Rxa-?oE-"},
		"grant_type":    {"client_credentials"},
		"scope":         {"https://graph.microsoft.com/.default"},
	})

	if err != nil {
		return err
	}
	b, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return err
	}
	var data map[string]interface{}
	err = json.Unmarshal(b, &data)
	if err != nil {
		return err
	}
	serverErrCode, ok := data["error"].(string)
	if ok {
		serverErr, ok := data["error_description"].(string)
		if ok {
			return fmt.Errorf("%v: %v", serverErrCode, serverErr)
		}
		return fmt.Errorf(serverErrCode)
	}
	accessToken, ok := data["access_token"].(string)
	if !ok || accessToken == "" {
		return fmt.Errorf("no access token found in response")
	}

  fmt.Println(data)
//  fmt.Println(data["access_token"])
  fmt.Println("Token type is: ", data["token_type"])
  fmt.Println("Expires_in is: ", data["expires_in"])

  // TODO - figure out why this fails to work
	// durationSecs, ok := data["expires_in"].(float64)
  // if !ok || durationSecs == 0 {
	// 	return fmt.Errorf("no token duration found in response")
	// }
	if h.Scopes.HasScope(scopes.DelegatedOfflineAccess) {
		refreshToken, ok := data["refresh_token"].(string)
		if !ok || refreshToken == "" {
			return fmt.Errorf("no refresh token found in response")
		}
		h.RefreshToken = refreshToken
	}
  expiresAt := time.Now().Add(1*time.Hour)
  fmt.Println("\nExpires At:", expiresAt)
//	expiresAt := time.Now().Add(time.Duration(durationSecs) * time.Second)
	h.RequestCredentials.AccessToken = accessToken
	h.RequestCredentials.AccessTokenExpiresAt = expiresAt
	return nil
} // InitializeCredentials


func createJSONforEmail() ([]byte){

  type FlagStruct struct {
  	FlagStatus string `json:"flagStatus"`
  }
  type BodyStruct struct {
  	ContentType string `json:"contentType"`
  	Content     string `json:"content"`
  }
  type EmailAddressStruct struct {
  	Address string `json:"address"`
  	Name    string `json:"name"`
  }
  type ToRecipientsStruct struct {
  	EmailAddress EmailAddressStruct `json:"emailAddress"`
  }
  type ReplyToStruct struct {
  	EmailAddress EmailAddressStruct `json:"emailAddress"`
  }
  type MessageStruct struct {
  	Subject      string               `json:"subject"`
  	Importance   string               `json:"importance"`
  	Flag         FlagStruct           `json:"flag"`
  	Body         BodyStruct           `json:"body"`
  	ToRecipient  []ToRecipientsStruct `json:"toRecipients"`
  	ReplyTo      []ReplyToStruct      `json:"replyTo"`
  }
  type MessageEnvelope struct {
  	Message         MessageStruct `json:"message"`
  	SaveToSentItems string        `json:"saveToSentItems"`
  }

  toEmailAddress := EmailAddressStruct{
    Address: "mark_wohlin@homedepot.com",
    Name: "Mark_Wohlin",
  }

  toRecipient := ToRecipientsStruct {
    EmailAddress: toEmailAddress,
  }

  replyToEmailAddress := EmailAddressStruct{
    Address: "Do_Not_Reply-SCNM@homedepot.com",
    Name: "DO-NOT-REPLY",
  }

  replyTo := ReplyToStruct {
    EmailAddress: replyToEmailAddress,
  }

  s := MessageEnvelope{
		Message: MessageStruct{
			Subject: "email subject",
			Importance: "High",
      Flag: FlagStruct{
        FlagStatus: "flagged",
      },
      Body: BodyStruct{
        ContentType: "Text",
        Content: "This is a test email...",
      },
      ToRecipient: []ToRecipientsStruct{
        toRecipient,
      },
      ReplyTo: []ReplyToStruct{
        replyTo,
      },
		},
    SaveToSentItems: "false",
	}

	JSONemail, err := json.MarshalIndent(s, "", "   ")
	if err != nil {
		log.Fatal(err)
	}

  return JSONemail
//	fmt.Printf("%s\n", JSONemail)
} // createJSONforEmail



func main(){
  // Get the access token from Microsoft Graph
  applicationID := ""
  applicationSecret := ""
  h := NewHeadless(applicationID, applicationSecret, scopes.All(scopes.PermissionTypeApplication))
  err := h.InitializeCredentials()

  if err != nil {
    fmt.Println(err.Error())
  }
  fmt.Println("The access token is:", h.RequestCredentials.AccessToken)


  // Create the JSON for the email posting
  JSONemail := createJSONforEmail()

  fmt.Printf("%s\n", JSONemail)


  // Set the access token in the authorization header of a new POST



  // Set the JSON into the HTTP POST
  // Send the email
  resp, err := http.Post("https://graph.microsoft.com/v1.0/users/Mark_Wohlin@HomeDepot.com/sendMail", "application/json", bytes.NewBuffer(JSONemail))
	if err != nil {
		log.Fatalln(err)
	}

	var result map[string]interface{}

	json.NewDecoder(resp.Body).Decode(&result)

	log.Println(result)
	log.Println(result["data"])





}
