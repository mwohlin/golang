package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"net/url"
	"time"
  "sync"
  "log"
//  "bytes"
	"strings"
	"math/rand"

	"github.com/mhoc/msgoraph/scopes"
)

// Client is an interface which all client types abide by. It guarantees operations around
// credentials; primarily getting, initializing, and refreshing.
type Client interface {
	Credentials() *RequestCredentials

	// InitializeCredentials should make the initial requests necessary to establish the first set of
	// authentication credentials within the Client.
	InitializeCredentials() error

	// RefreshCredentials should initiate an internal refresh of the request credentials inside this
	// client. This refresh should, whenever possible, check the
	// RequestCredentials.AccessTokenExpiresAt field to determine whether it should actually refresh
	// the credentials or if the credentials are still valid.
	RefreshCredentials() error
}

// RequestCredentials stores all the information necessary to authenticate a request with the
// Microsoft GraphAPI
type RequestCredentials struct {
	AccessToken          string
	AccessTokenExpiresAt time.Time
	AccessTokenUpdating  sync.Mutex
}

// Headless is used to authenticate requests in the context of a backend app. This is the most
// common way for applications to authenticate with the api.
type Headless struct {
	ApplicationID      string
	ApplicationSecret  string
	Error              error
	RefreshToken       string
	RequestCredentials *RequestCredentials
	Scopes             scopes.Scopes
}

// NewHeadless() creates a new headless connection.
func NewHeadless(applicationID string, applicationSecret string, scopes scopes.Scopes) *Headless {
	return &Headless{
		ApplicationID:      applicationID,
		ApplicationSecret:  applicationSecret,
		RequestCredentials: &RequestCredentials{},
		Scopes:             scopes,
	}
}

// Credentials() returns back the set of credentials used for every request.
func (h Headless) Credentials() *RequestCredentials {
	return h.RequestCredentials
}

// InitializeCredentials will make an initial oauth2 token request for a new token.
func (h Headless) InitializeCredentials() error {
	h.RequestCredentials.AccessTokenUpdating.Lock()
	defer h.RequestCredentials.AccessTokenUpdating.Unlock()
	if h.RequestCredentials.AccessToken != "" && h.RequestCredentials.AccessTokenExpiresAt.After(time.Now()) {
		return nil
	}
	tokenURI, err := url.Parse("https://login.microsoftonline.com/HomeDepot.onmicrosoft.com/oauth2/token")
	if err != nil {
		return err
	}

  // TODO: Set these in environment variables via a GKE secret
	resp, err := http.PostForm(tokenURI.String(), url.Values{
		"client_id":     {"76ffe6ac-5d9d-43b5-83d2-f313e3b7372b"},
		"client_secret": {"Sb?Lhx7+9@64+A=LgV*H/]6.Rxa-?oE-"},
		"grant_type":    {"client_credentials"},
		"resource":      {"https://graph.microsoft.com"},
		"scope":         {"https://graph.microsoft.com/.default"},    // Is scope needed?
	})

	if err != nil {
		return err
	}
	b, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return err
	}
	var data map[string]interface{}
	err = json.Unmarshal(b, &data)
	if err != nil {
		return err
	}
	serverErrCode, ok := data["error"].(string)
	if ok {
		serverErr, ok := data["error_description"].(string)
		if ok {
			return fmt.Errorf("%v: %v", serverErrCode, serverErr)
		}
		return fmt.Errorf(serverErrCode)
	}
	accessToken, ok := data["access_token"].(string)
	if !ok || accessToken == "" {
		return fmt.Errorf("no access token found in response")
	}

  fmt.Println(data)
  fmt.Println("Token type is: ", data["token_type"])
  fmt.Println("Expires_in is: ", data["expires_in"])

  // TODO - figure out why this fails to work
	// durationSecs, ok := data["expires_in"].(float64)
  // if !ok || durationSecs == 0 {
	// 	return fmt.Errorf("no token duration found in response")
	// }
	if h.Scopes.HasScope(scopes.DelegatedOfflineAccess) {
		refreshToken, ok := data["refresh_token"].(string)
		if !ok || refreshToken == "" {
			return fmt.Errorf("no refresh token found in response")
		}
		h.RefreshToken = refreshToken
	}
  expiresAt := time.Now().Add(1*time.Hour)
  fmt.Println("\nExpires At:", expiresAt)
//	expiresAt := time.Now().Add(time.Duration(durationSecs) * time.Second)
	h.RequestCredentials.AccessToken = accessToken
	h.RequestCredentials.AccessTokenExpiresAt = expiresAt
	return nil
} // InitializeCredentials()


func createJSONforEmail() ([]byte){

// This function will create a JSON email body which looks like this. This is
// required format to send to the Microsoft Graph API.
// {
//    "message": {
//       "subject": "email subject",
//       "importance": "High",
//       "flag": {
//          "flagStatus": "flagged"
//       },
//       "body": {
//          "contentType": "Text",
//          "content": "This is a test email..."
//       },
//       "toRecipients": [
//          {
//             "emailAddress": {
//                "address": "mark_wohlin@homedepot.com",
//                "name": "Mark_Wohlin"
//             }
//          }
//       ],
//       "replyTo": [
//          {
//             "emailAddress": {
//                "address": "Do_Not_Reply-SCNM@homedepot.com",
//                "name": "DO-NOT-REPLY"
//             }
//          }
//       ]
//    },
//    "saveToSentItems": "false"
// }

  type FlagStruct struct {
  	FlagStatus string `json:"flagStatus"`
  }
  type BodyStruct struct {
  	ContentType string `json:"contentType"`
  	Content     string `json:"content"`
  }
  type EmailAddressStruct struct {
  	Address string `json:"address"`
  	Name    string `json:"name"`
  }
  type ToRecipientsStruct struct {
  	EmailAddress EmailAddressStruct `json:"emailAddress"`
  }
  type ReplyToStruct struct {
  	EmailAddress EmailAddressStruct `json:"emailAddress"`
  }
  type MessageStruct struct {
  	Subject      string               `json:"subject"`
  	Importance   string               `json:"importance"`
  	Flag         FlagStruct           `json:"flag"`
  	Body         BodyStruct           `json:"body"`
  	ToRecipient  []ToRecipientsStruct `json:"toRecipients"`
  	ReplyTo      []ReplyToStruct      `json:"replyTo"`
  }
  type MessageEnvelope struct {
  	Message         MessageStruct `json:"message"`
  	SaveToSentItems string        `json:"saveToSentItems"`
  }

  toEmailAddress := EmailAddressStruct{
    Address: "mark_wohlin@homedepot.com",
    Name: "Mark_Wohlin",
  }

  toRecipient := ToRecipientsStruct {
    EmailAddress: toEmailAddress,
  }

  replyToEmailAddress := EmailAddressStruct{
    Address: "Do_Not_Reply-SCNM@homedepot.com",
    Name: "DO-NOT-REPLY",
  }

  replyTo := ReplyToStruct {
    EmailAddress: replyToEmailAddress,
  }

  s := MessageEnvelope{
		Message: MessageStruct{
			Subject: "email subject",
			Importance: "High",
      Flag: FlagStruct{
        FlagStatus: "flagged",
      },
      Body: BodyStruct{
        ContentType: "Text",
        Content: "This is a test email...",
      },
      ToRecipient: []ToRecipientsStruct{
        toRecipient,
      },
      ReplyTo: []ReplyToStruct{
        replyTo,
      },
		},
    SaveToSentItems: "false",
	}

	JSONemail, err := json.MarshalIndent(s, "", "   ")
	if err != nil {
		log.Fatal(err)
	}

  return JSONemail
} // createJSONforEmail()


func controller(w http.ResponseWriter, r *http.Request) {
  // reply
	rand.Seed(time.Now().UTC().UnixNano())
	message := r.URL.Path
  message = strings.TrimPrefix(message, "/")
  message = "Hello " + message + " - " + randomString(10)
  w.Write([]byte(message))

  // Print the incoming reqeust headers
	// fmt.Fprintf(w, "%s %s %s\n", r.Method, r.URL, r.Proto)
	// for k, v := range r.Header {
	// 	fmt.Fprintf(w, "Header[%q] = %q\n", k, v)
	// }
	// fmt.Fprintf(w, "Host = %q\n", r.Host)
	// fmt.Fprintf(w, "RemoteAddr = %q\n", r.RemoteAddr)
	// if err := r.ParseForm(); err != nil {
	// 	log.Print(err)
	// }
	// for k, v := range r.Form {
	// 	fmt.Fprintf(w, "Form[%q] = %q\n", k, v)
	// }

	//	Body io.ReadCloser
	b, err := ioutil.ReadAll(r.Body)
	if err != nil {
	    panic(err)
	}
	fmt.Printf("%s", b)

	// TODO: Map the incoming request into the email JSON which will be sent to Microsoft GraphAPI




  // HANDLE INCOMING REQUEST
	// Get the access token from Microsoft Graph
  applicationID := ""
  applicationSecret := ""
  h := NewHeadless(applicationID, applicationSecret, scopes.All(scopes.PermissionTypeApplication))
  err := h.InitializeCredentials()

  if err != nil {
    fmt.Println(err.Error())
  }
  fmt.Println("The access token is:", h.RequestCredentials.AccessToken)

  // Create the JSON for the email posting
  JSONemail := createJSONforEmail()
  fmt.Printf("%s\n", JSONemail)

  // Set the access token in the authorization header of a new POST
  var bearerToken = "Bearer " + h.RequestCredentials.AccessToken
  var url = "https://graph.microsoft.com/v1.0/users/Mark_Wohlin@HomeDepot.com/sendMail"

	req, err := http.NewRequest("POST", url, bytes.NewBuffer(JSONemail))
	if err != nil {
	   panic(err)
	}

	// set Request Headers
	req.Header.Add("Content-Type", "application/json")
	req.Header.Add("Authorization", bearerToken)
  fmt.Println("\nThe Request Header is:\n",req.Header)

	// send request with headers
	client := &http.Client{}
	response, err := client.Do(req)
	var result map[string]interface{}
	json.NewDecoder(response.Body).Decode(&result)
	log.Println(result)

} // controller()

func main(){
	// Start a HTTP Server and listen for requests
	// This will block and run until it is killed
	http.HandleFunc("/", controller)
	if err := http.ListenAndServe(":8383", nil); err != nil {
    panic(err)
  }
} // main()

func randomString(l int) string {
    bytes := make([]byte, l)
    for i := 0; i < l; i++ {
        bytes[i] = byte(randInt(65, 90))
    }
    return string(bytes)
} // randomString()

func randInt(min int, max int) int {
    return min + rand.Intn(max-min)
} // randInt()
